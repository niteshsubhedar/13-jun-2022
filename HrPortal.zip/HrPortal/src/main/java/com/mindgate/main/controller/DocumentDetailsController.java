package com.mindgate.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindgate.main.pojo.CandidateDetails;
import com.mindgate.main.pojo.DocumentDetails;
import com.mindgate.main.service.CandidateDetailsServiceInterface;
import com.mindgate.main.service.DocumentDetailsSeviceInterface;

@RestController
@CrossOrigin(origins = "http://localhost:4200/")
@RequestMapping("documentdetails")
public class DocumentDetailsController {

	
	@Autowired
	private DocumentDetailsSeviceInterface documentDetailsSeviceInterface;
	
	@RequestMapping(value = "documentdetail" , method = RequestMethod.GET)
	public List<DocumentDetails> getAllDocumentDetails(){
		return documentDetailsSeviceInterface.getAllDocumentDetails();
	}
	
	@RequestMapping(value = "documentdetail/{documentId}" , method = RequestMethod.GET)
	public DocumentDetails getDetails(@PathVariable int documentId) {
		return documentDetailsSeviceInterface.getDocumentDetailsByDocumentId(documentId);
	}
}
