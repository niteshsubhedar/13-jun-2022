package com.mindgate.main.repository;

import java.util.List;

import com.mindgate.main.pojo.InterviewDetails;

public interface InterviewDetailsRepositoryInterface {
	public boolean addNewInterviewDetails(InterviewDetails interviewDetails);
	public boolean updateInterviewDetailsByInterviewId(InterviewDetails interviewDetails);
	public boolean deleteInterviewDetailsByInterviewId(int interviewId);
	public InterviewDetails getInterviewDetailsById(int interviewId);
	public List<InterviewDetails> getAllInterviewDetails();

	
	public List<InterviewDetails> getAllInterviewDetailsAsInprocess();
}
