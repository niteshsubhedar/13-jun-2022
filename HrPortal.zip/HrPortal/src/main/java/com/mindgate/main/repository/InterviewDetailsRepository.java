package com.mindgate.main.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mindgate.main.pojo.InterviewDetails;

@Repository
public class InterviewDetailsRepository implements InterviewDetailsRepositoryInterface{

	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	InterviewDetailsRowMapper interviewDetailsRowMapper;
	
	/*
CREATE TABLE INTERVIEW_DETAILS(
INTERVIEW_ID NUMBER(8), 
STATUS VARCHAR(50) CHECK (STATUS IN('NEW','SELECTED','PENDING','INPROCESS','REJECTED')),
CANDIDATE_ID NUMBER(8),
FEEDBACK VARCHAR(50),
INTERVIEWER_ID NUMBER(8),
INTERVIEW_DATE DATE,
CONSTRAINT pk_interview_id PRIMARY KEY ( INTERVIEW_ID ),
CONSTRAINT fk_candidate_id_intervied_details FOREIGN KEY ( CANDIDATE_ID )
REFERENCES CANDIDATES_DETAILS ( CANDIDATE_ID ),
CONSTRAINT fk_interviewer_id_intervied_details FOREIGN KEY ( INTERVIEWER_ID )
REFERENCES EMPLOYEE_DETAILS ( EMPLOYEE_ID )
);
*/
	
	private static final String SELECT_ALL_INTERVIEW_DETAILS = "SELECT * FROM INTERVIEW_DETAILS";
	private static final String SELECT_SINGLE_INTERVIEW_DETAILS = "SELECT * FROM INTERVIEW_DETAILS WHERE INTERVIEW_ID = ?";
	private static final String UPDATE_INTERVIEW_DETAILS = "UPDATE INTERVIEW_DETAILS SET STATUS = ?, CANDIDATE_ID = ?, FEEDBACK = ?, INTERVIEWER_ID =? ,INTERVIEW_DATE = ?"
			+ "	WHERE INTERVIEW_ID = ?";
	private static final String DELETE_INTERVIEW_DETAILS = "DELETE INTERVIEW_DETAILS WHERE INTERVIEW_ID = ?";

	private int resultCount;

	
	private static final String INSERT_INTERVIEW_DETAILS = "INSERT INTO INTERVIEW_DETAILS(INTERVIEW_ID,STATUS,CANDIDATE_ID,FEEDBACK,INTERVIEWER_ID,INTERVIEW_DATE)VALUES(SEQ_INTERVIEW_DETAILS.NEXTVAL,?,?,?,?,?)";
/*                                                          INSERT INTO INTERVIEW_DETAILS(INTERVIEW_ID,STATUS,CANDIDATE_ID,FEEDBACK,INTERVIEWER_ID,INTERVIEW_DATE)VALUES(SEQ_INTERVIEW_DETAILS.NEXTVAL,'INPROCESS',1,'GOOD IN JAVA',6,'12-JUN-2022');
*/
	@Override
	public boolean addNewInterviewDetails(InterviewDetails interviewDetails) {
		System.out.println("inserting new INTERVIEW details into database");
		System.out.println(interviewDetails);
		/* (INTERVIEW_ID,STATUS,CANDIDATE_ID,FEEDBACK,INTERVIEWER_ID,INTERVIEW_DATE)VALUES(SEQ_INTERVIEW_DETAILS.NEXTVAL,'INPROCESS',1,'GOOD IN JAVA',6,'12-JUN-2022');
		*/
		Object[] args = {interviewDetails.getStatus(),
				interviewDetails.getCandidateDetails().getCandidateId(),
				interviewDetails.getFeedback(),interviewDetails.getEmployeeDetails().getEmployeeId(),
				interviewDetails.getInterviewDate()};

		resultCount = jdbcTemplate.update(INSERT_INTERVIEW_DETAILS, args);

		if (resultCount > 0)
			return true;
		else
			return false;	}

	@Override
	public boolean updateInterviewDetailsByInterviewId(InterviewDetails interviewDetails) {
		Object[] args = { interviewDetails.getStatus(), interviewDetails.getCandidateDetails().getCandidateId(), interviewDetails.getFeedback(),interviewDetails.getEmployeeDetails().getEmployeeId(),interviewDetails.getInterviewDate(),interviewDetails.getInterviewId()};
		resultCount = jdbcTemplate.update(UPDATE_INTERVIEW_DETAILS, args);
		if (resultCount > 0)
			return true;
		else
			return false;
	}

	@Override
	public boolean deleteInterviewDetailsByInterviewId(int interviewId) {
		Object[] args = { interviewId };
		resultCount = jdbcTemplate.update(DELETE_INTERVIEW_DETAILS, args);
		if (resultCount > 0)
			return true;
		else
			return false;	}

	@Override
	public InterviewDetails getInterviewDetailsById(int interviewId) {

		Object[] args = { interviewId };
		InterviewDetails employee = jdbcTemplate.queryForObject(SELECT_SINGLE_INTERVIEW_DETAILS, interviewDetailsRowMapper,args);
		System.out.println("get single "+employee);
		return employee;
	}

	@Override
	public List<InterviewDetails> getAllInterviewDetails() {
		
		List<InterviewDetails> allEmployees = jdbcTemplate.query(SELECT_ALL_INTERVIEW_DETAILS, interviewDetailsRowMapper);
		return allEmployees;
	}

	private static final String SELECT_ALL_INPROCESS_INTERVIEW_DETAILS = "SELECT * FROM INTERVIEW_DETAILS WHERE STATUS = 'INPROCESS' ";
	@Override
	public List<InterviewDetails> getAllInterviewDetailsAsInprocess() {
		// TODO Auto-generated method stub
		List<InterviewDetails> inprocessEmployees=jdbcTemplate.query(SELECT_ALL_INPROCESS_INTERVIEW_DETAILS, interviewDetailsRowMapper);
		return inprocessEmployees;
	}

}
